$Search_folder_path = "C:\Users\jc41809-sw\Downloads\Work Scripts"
$AD_Users = Get-ADUser -SearchBase "OU=Enterprise,OU=gasou,DC=ad,DC=georgiasouthern,DC=edu" -Filter * -Properties *|ConvertTo-Csv
$ADPriority_Users = Get-ADUser -SearchBase "OU=Privileged Accounts,OU=gasou,DC=ad,DC=georgiasouthern,DC=edu" -Filter * -Properties *|ConvertTo-Csv

if (Test-Path -path "$Search_folder_path\AD_User_properties.csv"){
    Set-Content -Path "$Search_folder_path\AD_User_properties.csv"-Value $AD_Users
}else{
     Add-Content -Path "$Search_folder_path\AD_User_properties.csv" -Value $AD_Users
}


if (Test-Path -path "$Search_folder_path\AD_PUser_properties.csv"){
    Set-Content -Path "$Search_folder_path\AD_PUser_properties.csv"-Value $ADPriority_Users
}else{
     Add-Content -Path "$Search_folder_path\AD_PUser_properties.csv" -Value $ADPriority_Users
}





