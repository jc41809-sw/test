import pandas as pd
import csv
import numpy as np
import datetime

#getting current date and time of creation and storing it as a variable
now = datetime.datetime.now()
#formatting that into a string
now = now.strftime("%Y%m%d")
#file path out is the variable used to store the location of where you want the file to go
file_path_out = ""
#file path in is the variable that is used to retrieve the data needed for the KPI
file_path_in = "KB4_AllEnrollmentsWithGroupInfo.csv"
#file path of all users containing both the universities and departments
file_path_in_additional = "KB4_AllUsers.csv"
#This will be the main set of data used for creating the KPI
KPI_data = []
#This is the supporting set of data for creating the KPI
KPI_support = []
#The variable for the training metrics 
training_metrics_data = "campaign_name"
#The variable used for the group metrics 
group_metrics_data = "userGroups"

def main():
    """
    This main function is used to pass in a CSV file to parse through for the 
    KPI then it calls the below functions and crraetes a report from the craeted datasheets
    """
  
#opening and reading the csv file from sharepoint forthe main 
    with open (file_path_in, "r") as file:
        reader_csv = csv.DictReader(file)
        for row in reader_csv:
            KPI_data.append(row)

    with open (file_path_in, "r") as file:
        reader_csv = csv.DictReader(file)
        for row in reader_csv:
            KPI_data.append(row)


    #Creating the dataframe to pass into the training and group methods
    SearchBase = pd.DataFrame(KPI_data)
    #Creating the dataframes for the user and SW methods
    dataframeUserSW = pd.DataFrame(columns=['id', 'first_name', 'last_name', 'module_name', 'userGroups', 'status'])
    
    #creating the datasheets from the kpi data
    pdUsers = passdueUser(KPI_data)
    pdSW = passdueSW(KPI_data)
    groupMetrics = group_metrics(SearchBase, group_metrics_data)
    trainingMetrics = training_metrics(SearchBase, training_metrics_data)

    #opens a writer to create a xlsx file
    with pd.ExcelWriter(f'KPI {now}.xlsx', engine='xlsxwriter') as writer:


        #Writes the datasheets to the file using the functions called
        pdUsers.to_excel(writer, sheet_name='User Past Due', index=False, header=[True])
        pdSW.to_excel(writer, sheet_name='Student Worker Past Due', index=False, header=True)
        groupMetrics.to_excel(writer, sheet_name='Group Metrics', index=False, header=True)
        trainingMetrics.to_excel(writer, sheet_name='Training Metrics', index=False, header=True)


def passdueUser(data):
    """ This function is used to create the sheet for the past due users """

    try:
        #creates a dataframe based on the below data
        dataframeUser = pd.DataFrame(columns=['id', 'first_name', 'last_name', 'module_name', 'userGroups', 'status'])

        #loops through the dataframe we created  and searches for the past due in the status column
        for rows in range(len(data)):
            if data[rows]["status"] == "Past Due":
                #from there it checks to see if that person is not a student worker
                if "SW" not in data[rows]["userGroups"]:
                    #Saves all of the data that is past due in the original dataframe
                    dataframeUser.loc[rows] = [data[rows]["id"], data[rows]["first_name"], data[rows]["last_name"], data[rows]["module_name"], data[rows]["userGroups"], data[rows]["status"]]

         #returning the dataframe
        return dataframeUser
    
    except Exception as e:
        print ( " Error creating sheet for the pastdue users please review data for correct formatting")


def passdueSW(data):
    """ This function is used to create the sheet for the past due Student Workers """

    try:
        #creates a dataframe based on the below data
        dataframeSW = pd.DataFrame(columns=['id', 'first_name', 'last_name', 'module_name', 'userGroups', 'status'])

        #loops through the dataframe we created  and searches for the past due in the status column
        for rows in range(len(data)):
            if data[rows]["status"] == "Past Due":
                #from there it checks to see if that person is a student worker
                if "SW" in data[rows]["userGroups"]:
                    #Saves all of the data that is past due in the original dataframe
                    dataframeSW.loc[rows] = [data[rows]["id"], data[rows]["first_name"], data[rows]["last_name"], data[rows]["module_name"], data[rows]["userGroups"], data[rows]["status"]]
         #returning the dataframe
        return(dataframeSW) 

    except Exception as e:
        print ( " Error creating sheet for the pastdue users please review data for correct formatting")


def group_metrics(SearchBase, group_metrics_data):
    """This method uses the data and group metrics data keyword to create a KPI using of the highest and lowest preforming groups"""
    try:
        #Dropping all of the duplicate cells based on the user groups data
        groupMetric = SearchBase.drop_duplicates(subset=[f'{group_metrics_data}'])
        #splitting up all of the singular cells by the "," delimitter and expanding them across all of the adjacent cells to review
        groupMetric = groupMetric[f'{group_metrics_data}'].str.split(',', expand=True)
        #stacking up all of those previously scattered cells into a single column
        groupMetric = groupMetric.stack().rename(f'{group_metrics_data}').reset_index(drop = True)
        #dropping the duplicated cells from the list to make it all one Series
        groupMetric  = groupMetric.drop_duplicates()
        # Changing the serties back into a data frame
        groupMetric = groupMetric.to_frame()
        #Strips all leading and trailing spaces
        groupMetric[f"{group_metrics_data}"] = groupMetric[f"{group_metrics_data}"].str.strip()
        #Clears all duplicates for the final list 
        groupMetric = groupMetric.drop_duplicates()
        #Adds a column named passed that is instantiated by a list of zeros
        groupMetric['status'] = "Passed" 
        #Adds a column named passed that is instantiated by a list of zeros
        groupMetric['Count'] = np.zeros(len(groupMetric))
        #resets the index of the dataframe for readability
        groupMetric  = groupMetric.reset_index()
        #deletes the previos indexes
        groupMetric = groupMetric.drop("index", axis=1)  

        #Pulls the data from the 'UserGroup' column and converts it into a list 
        strList = groupMetric[f'{group_metrics_data}'].to_list()
        #Creating a map of the keys to go through
        strmap = dict.fromkeys(strList, 0)  
        #Loops through the the original 'userGroups' column in the data 
        for col in SearchBase[f'{group_metrics_data}']:
           #creates a list to compare the user columns to
           Participating_groups = col.split(",")
           # loops through the participating groups list        
           for index in range(len(Participating_groups)):            
               checker = Participating_groups[index].strip()
               #Comparing each word in the list to ist of words to find a match and if there is we add one to that space
               if checker in strList:              
                   #Getting the row information so we can pinpoint the space we need to add one to
                   if checker in strmap:
                       strmap[checker]+= 1
                       
        #Loops through the length of the list of user groups and adds the valuesto the data frame          
        for index in range(len(strList)):
           comparitor = strList[index].replace(" ", "")
           groupMetric.loc[index,"Count"] += strmap[strList[index]]

         #returning the dataframe
        return groupMetric
    
    except Exception as e:
        print ( "Error creating sheet for the following document please review data for correct formatting")


def training_metrics(SearchBase, training_metrics_data):
    """This method is used to create training metrics based on the input data showing the most and least completeed trainings"""

    try:
        
        #Dropping all of the duplicate cells based on the user groups data
        trainingMetric = SearchBase.drop_duplicates(subset=[f'{training_metrics_data}'])
        #splitting up all of the singular cells by the "," delimitter and expanding them across all of the adjacent cells to review
        trainingMetric = trainingMetric[f'{training_metrics_data}'].str.split(',', expand=True)
        #stacking up all of those previously scattered cells into a single column
        trainingMetric = trainingMetric.stack().rename(f'{training_metrics_data}').reset_index(drop = True)     
        # Changing the series back into a data frame
        trainingMetric = trainingMetric.to_frame()   
        #Adds a column named passed that is instantiated by a list of zeros
        trainingMetric['status'] = "Passed"   
        #Adds a column named passed that is instantiated by a list of zeros
        trainingMetric['Count'] = np.zeros(len(trainingMetric))
        #resets the index of the dataframe for readability
        trainingMetric  = trainingMetric.reset_index()
        #deletes the previos indexes
        trainingMetric = trainingMetric.drop("index", axis=1) 

        #Pulls the data from the 'UserGroup' column and converts it into a list 
        strList = trainingMetric[f'{training_metrics_data}'].to_list()
        #Creating a map of the keys to go through
        strmap = dict.fromkeys(strList, 0)
        #Loops through the the original 'userGroups' column in the data 
        for col in SearchBase[f'{training_metrics_data}']:
           #creates a list to compare the user columns to
           if col in strList:
               strmap[col] += 1

        #Loops through the length of the list of user groups and adds the valuesto the data frame          
        for index in range(len(strList)):
           #loops through and adds the passed count to the dataframe
           trainingMetric.loc[index,"Count"] += strmap[strList[index]]

        #returning the dataframe
        return trainingMetric
    
        #throws exception in the case that dataframe cannot be created
    except Exception as e:
        print ( "Error creating sheet for the following document please review data for correct formatting")


main()


