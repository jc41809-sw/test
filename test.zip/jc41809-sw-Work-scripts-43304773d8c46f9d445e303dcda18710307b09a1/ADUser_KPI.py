#!/usr/bin/env python3
# Jaheim Cain
# 
import pandas as pd
import datetime
from datetime import timedelta
import json



#Input file path
filepath_in = 'AD_user_properties.csv'

#output file path and  name for the output
filepath_out = 'AD_users_Pastdue.json'
KPIname = 'AD_UPD'

#Gettig current date 
now = datetime.datetime.now()
formatted_date = now.strftime("%m/%d/%Y")

#dataframe used for processing all of the information
pastdue_passwords = pd.read_csv(filepath_in)



   


def process_by_dates():
    #used to keep track of the return dataframe 
    placer=0
    #the frame that will be used to convert to json
    return_frame = pd.DataFrame(columns=['SamAccountName','PasswordLastSet'])
    #replacing all null values with a date of 1700 jan 1st
    pastdue_passwords.fillna('1700-01-01 00:00:00', inplace=True)
    #loops through the dataframe to get password info
    for index in range(len(pastdue_passwords)):
            #converts the passwords into a datetime object
            date = (pastdue_passwords.loc[index]['PasswordLastSet'])
            date = pd.to_datetime(date)
            #if datetime is a year or more old it goes on the list 
            if date < now - timedelta(days=365):
                return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'], pastdue_passwords.loc[index]['PasswordLastSet']] 
                placer+=1
    return return_frame


def check_exp_date():
     #Creates a return frame and a placer for the return value
     return_frame = pd.DataFrame(columns=['SamAccountName','NoExpirationDateSet'])
     placer = 0
      #Looping for the accounts and if an account's password does not expire then add to return frame
     for index in range(len(pastdue_passwords)):
          if pastdue_passwords.loc[index]['PasswordNeverExpires'] == True:
               return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'],pastdue_passwords.loc[index]['PasswordNeverExpires']]
               placer+=1

     return return_frame

def check_can_change():
     #Creates a return frame and a placer for the return value
    return_frame = pd.DataFrame(columns=['SamAccountName','CanChangePswd'])
    placer = 0
    #Looping for the accounts and if an account can change their password then add to return frame
    for index in range(len(pastdue_passwords)):
          if pastdue_passwords.loc[index]['CannotChangePassword'] == False:
               return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'],True]
               placer+=1

    return return_frame
               
        
if __name__ == '__main__':

#Creating dataframes for the objects 
   renewed_pwd_needed = process_by_dates()
   pwd_doesnt_expire = check_exp_date()
   can_change_pwd = check_can_change()
   
#Converting the dataframe into and excel book
   with pd.ExcelWriter(f'{KPIname}.xlsx', engine='xlsxwriter') as writer:
       renewed_pwd_needed.to_excel(writer, sheet_name='AD Metrics1', index=False, header=True)
       pwd_doesnt_expire.to_excel(writer, sheet_name='AD Metrics2', index=False, header=True)
       can_change_pwd.to_excel(writer, sheet_name='AD Metrics3', index=False, header=True)

   