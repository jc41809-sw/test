import os
import subprocess
import json
import concurrent.futures
import datetime
import time
import re



#place working and results file paths here
working_folder = r'Working folder file path'
results_folder = os.path.join(working_folder, 'Results')


# Clear out last run's results from results folder  (Delete if not needed)
for filename in os.listdir(results_folder):
    file_path = os.path.join(results_folder, filename)
    try:
        if os.path.isfile(file_path):
            os.remove(file_path)
    except Exception as e:
        print(f"Error deleting file {file_path}: {e}")




# GAM command path
gam_path = r"Gam path goes here"


#Declaration of program start
start = time.time()
print (f"Program Start time: {datetime.datetime.now()}")


#list that stores the emails that are needing to be reviewed
EmailstolookAt = []

#Loops through the emails 
try:
    #Goes through all of the emails (replace the emails.txt file with the filepath to the email file )
    with open("emails.txt", "r") as f:
        emails = [line.strip() for line in f]
        
#error in the case the email cannot be read
except FileNotFoundError:
    print("Error: emails.txt not found.")
    exit()





#Checks the string for any matching regular expression
def regexCase(text, word1, word2):
    
    #pattern for both keywords with no new line inbetween them
    pattern = r"\b" + re.escape(word1) + r"\b.*?\b" + re.escape(word2) + r"\b"
    #checks the text for the given pattern
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)  # Case-insensitive

   # if pattern matched text return true otherwise return false
    if match:
        matched_text = match.group(0)
        if "\n" not in matched_text:
            return True
    return False









def emailToJson(emails):

   try:

    
    ## Sets encoding to utf-8 so we can read what is in the response
    encoding = 'utf-8'

    #this will be used to call the gam function ( replace the variable parameters with the gam path and command function)
    command = ["curl", "gam command goes here"]

    #returns the output from the command call
    res = subprocess.Popen(command, stdout = subprocess.PIPE, stderr=subprocess.PIPE)

    #comunicates to the two variables in the form of bytes 
    (out,err) = res.communicate()

  #creates output variables in the form of strings to review via regex
    outputH = str(out,encoding)
    errorH = str(err,encoding)
    

#Calls the placeholder function to read outputs
    placeholderCheck(outputH, emails)


  
# placeholer error to check if email does not exist
   except Exception as e:
      print ("Error Email does not exist")
      EmailstolookAt.append(f"Email does not exist for {emails} no data collected")
     
   









# Used  to check the contents of the string and returns the email if suspicious
def placeholderCheck(teststr, email):
   try:
            
            #placeholder filters let me know if it needs to be adjusted but as needed just change the contents of word 1 and 2 and adjust the variable name to whatever you have 
            #for the parameter
            word1 = "Parameters part 1 go here"   
            word2 = "parameters part 2 go here" 
            isTrue = regexCase(teststr, word1, word2)  
            print(teststr)
            print(type(teststr))


               #Condition for the regex case 
            if  isTrue:
                      #adds to the array the emails that have suspicious filters
                        EmailstolookAt.append(f"{email}.json has suspicious filters" )

                        #Creates a json file for the email
                        with open (f"{email}.json","w")as file:
                           file.write(teststr)
                        
                        
            else:
               print(f"{email} checks out")


        
#Base exception case for if there is a problem running the JSON
   except Exception as e:

      #Declaring that the email will be saved to the log of emails to review then saving it 
      print ("json could not be read saving to log")
      EmailstolookAt.append(f"json could not be read (other error) for {email}.json")

      #Creates a json file for the email
      with open (f"{email}.json","w")as file:
                           file.write(teststr)


# exception for if Json file cannot be decoded
   except json.JSONDecodeError:  
            
            #prints that the emails filter could not be decoded
            print(f"Warning: Could not decode JSON for {email}. Check the GAM output.")
            EmailstolookAt.append(f"Could not decode JSON for {email}")

            #Creates a json file for the email
            with open (f"{email}.json","w")as file:
                           file.write(teststr)
    

# exception in the process for calling GAM
   except subprocess.CalledProcessError as e:
        print(f"Error running GAM for {email}: {e}")
        
        # Print error output from GAM
        print(f"GAM Output: {e.stderr}") 
       
        #Adds emails to the list of ones to manually check
        EmailstolookAt.append(f"Could not get output for {email} ")

        #Creates a json file for the email
        with open (f"{email}.json","w")as file:
                           file.write(teststr)









#Allows the program to run in parallel
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor: 
   
      #Designates the task that needs to run
   
      executor.map(emailToJson, emails)

   
    





#Creates extra line for output
print(" \n")






#Creates a simple report on all of the emails that need to be checked
print("\n Emails that need to be looked at: \n")
for i in range(len(EmailstolookAt)):
    print(f" {EmailstolookAt[i]} \n")






#ending timer for program
end = time.time()

#Giving the time that the code  completed
print (f"  \n Program End time: {datetime.datetime.now()}")

#declaring the end to the program with approx time it took to complete
print( f"\n This program completed in {end - start} seconds")