import matplotlib.pyplot as plt
import pandas as pd 
import re as regex
from datetime import datetime 
from matplotlib.backends.backend_pdf import PdfPages
import math
import numpy as np


date_format = "%m/%d/%Y %H:%M:%S"
#Getting campaign and user information
trainings = pd.read_csv('C:\\Know_Be_4_Records\\KB4_AllCampaigns.csv')
trainings  = trainings[['name', 'start_date', 'end_date']]
trainings = trainings.drop_duplicates(subset='name')


training_Names = trainings['name'].to_list()
#training_catagories = dict.fromkeys(training_Names, pd.DataFrame(columns=['Name', 'Start_Date', 'End_Date']))
training_catagories = {key : pd.DataFrame(columns=['campaign_name','enrollment_date', 'completion_date']) for key in training_Names}
training_indexes = dict.fromkeys(training_Names, 0)

users = pd.read_csv('C:\\Know_Be_4_Records\\KB4_AllEnrollmentsWithGroupInfo.csv')
users = users[['campaign_name','enrollment_date', 'completion_date' ]]


completion_metrics = []
timeframes = []

d = 0
def getcompletion_metrics(training, tname):
     training.fillna(-1, inplace=True)
     completion_percentile = 0
   
     start = trainings.iloc[tname, 1]
     end = trainings.iloc[tname, 2]
     if type(start) == str and  type(end) == str:
          start = start.replace(' AM', '')
          end = end.replace(' AM', '')
          start = start.replace(' PM', '')
          end = end.replace(' PM', '') 
     else:
          return -1

     start = datetime.strptime(start,date_format)
     end = datetime.strptime(end,date_format)
    
     distance = math.floor(((end - start ).total_seconds())/86400 )
    #  print (distance)
     timeframes.clear()

     
     count =  [0,0,0,0,0] 
       
          
     
     days = distance
    
     if distance > 15 and 'Verbaige' not in trainings.iloc[tname, 0] and 'C suite Test' not in trainings.iloc[tname,0]:
        
          while days > 0:
               timeframes.append(days)
               days = math.floor(days - (distance/4))
          timeframes[len(timeframes)-1] = 1
          for index in range(len(training)):
               completion_percentile = training.iloc[index, 2]
               if completion_percentile == -1: 
                    count[len(count)-1] +=1
               else:
                         completion_percentile = completion_percentile.replace(' PM', '')
                         completion_percentile = completion_percentile.replace(' AM', '')
                         completion_percentile =   datetime.strptime(completion_percentile,date_format)
                         completion_percentile = math.floor(((end - completion_percentile).total_seconds())/86400)


                         for tindex in range(len(timeframes)):
                              if abs(completion_percentile) >= timeframes[tindex]:
                                   count[tindex] += 1               
          return count 
     else:
          return -1
     
def to_PDF( name, timeframe):
          
          
         
          
          

          
          labels = ['First Week','Second Week' , 'Third Week', 'Fourth Week and beyond', 'Not Completed']
          # for index in range(math.floor(len(completion_metrics)/2)):
          #      temp = completion_metrics[len(completion_metrics)-index]
          #      completion_metrics[len(completion_metrics)-index] = completion_metrics[index]
          #      completion_metrics[index] = temp

          for i in range(len(labels)):
               addition = f'\n Amount: {completion_metrics[i]}'
               transition = labels[i] + addition

               labels[i] = transition
          
          fig, axes = plt.subplot_mosaic([['left', 'left'],
                                      ['left','left']],
                              figsize=(10.7, 7.3), layout="constrained")
          
          print(completion_metrics)
          axes['left'].plot( timeframe,completion_metrics, marker='o', linestyle='-')
          
          axes['left'].set_xlim(timeframe[0], 0)
          axes['left'].set_ylabel("User amounts")
          axes['left'].set_xlabel('Days Left')

          for i, txt in enumerate(labels):
               axes['left'].text(timeframe[i], completion_metrics[i],txt )

          fig.suptitle(f'{name} Stats Over Time')
          plt.close(fig)

          return fig
     
if __name__ == "__main__":
     
     with PdfPages ('Trainings_Over_Time.pdf') as file:
    
         for index in range(len(users)): 
               training_catagories[users.iloc[index, 0]].loc[training_indexes[users.loc[index,'campaign_name']]] = [users.iloc[index,0], users.iloc[index,1],users.iloc[index,2]]
          
               training_indexes[users.loc[index,'campaign_name']] += 1
         
         
         for index in range(len(training_Names)):
              print(training_Names[index])
              completion_metrics = getcompletion_metrics(training_catagories[training_Names[index]], index)
        
              if completion_metrics != -1:
               reference_timeframe = timeframes
               if len(reference_timeframe ) < 5:
                    reference_timeframe.append(0)

              

               figure = to_PDF(training_Names[index], reference_timeframe,)
               file.savefig(figure)
             

