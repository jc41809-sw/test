#!/usr/bin/env python3
# Jaheim Cain
#Unit Test for the dataSift function in intuneKPIviarequests.py to make sure it properky sifts data from the function

import unittest
from unittest.mock import patch, MagicMock
from intuneKPIviarequests import dataSift  # Assuming the class is in a file named intuneKPI.py
import json

states = {
    'value': [
        {'managementStateName': 'Managed', 'managementStateKey': 1},
        {'managementStateName': 'Unmanaged', 'managementStateKey': 2}
    ]
}




devices = {
    'value': [
        {
            'managementStateKey': 1,
            'encryptionState': 0,
            'deviceId': '123',
            'deviceName': 'Device1',
            'enrolledDateTime': '2023-01-01T00:00:00Z',
            'lastSyncDateTime': '2023-01-02T00:00:00Z',
            'azureADDeviceId': 'AAD123',
            'azureADRegistered': True,
            'osVersion': '10.0.19041',
            'easDeviceId': 'EAS123',
            'serialNumber': 'SN123',
            'userId': 'User1',
            'rowLastModifiedDateTimeUTC': '2023-01-03T00:00:00Z',
            'manufacturer': 'Manufacturer1',
            'model': 'Model1',
            'operatingSystem': 'Windows',
            'isDeleted': False,
            'ethernetMacAddress': None,
            'primaryUser': None
        },
        {
            'managementStateKey': 1,
            'encryptionState': 1,
            'deviceId': '124',
            'deviceName': 'Device2',
            'enrolledDateTime': '2023-01-01T00:00:00Z',
            'lastSyncDateTime': '2023-01-02T00:00:00Z',
            'azureADDeviceId': 'AAD124',
            'azureADRegistered': True,
            'osVersion': '10.0.19041',
            'easDeviceId': 'EAS124',
            'serialNumber': 'SN124',
            'userId': 'User2',
            'rowLastModifiedDateTimeUTC': '2023-01-03T00:00:00Z',
            'manufacturer': 'Manufacturer2',
            'model': 'Model2',
            'operatingSystem': 'Windows',
            'isDeleted': False,
            'ethernetMacAddress': None,
            'primaryUser': None 
        },
        {
            'managementStateKey': 1,
            'encryptionState': 1,
            'deviceId': '124',
            'deviceName': 'Device2',
            'enrolledDateTime': '2023-01-01T00:00:00Z',
            'lastSyncDateTime': '2023-01-02T00:00:00Z',
            'azureADDeviceId': 'AAD124',
            'azureADRegistered': True,
            'osVersion': '10.0.19041',
            'easDeviceId': 'EAS124',
            'serialNumber': 'SN124',
            'userId': 'User2',
            'rowLastModifiedDateTimeUTC': '2023-01-03T00:00:00Z',
            'manufacturer': 'Manufacturer2',
            'model': 'Model2',
            'operatingSystem': 'Windows',
            'isDeleted': False,
            'ethernetMacAddress': None,
            'primaryUser': None 
        }
    ]
}

class TestDataSift(unittest.TestCase):
    def testDataSift(self):
        # Mocking the dataSift function
        with patch('intuneKPIviarequests.dataSift') as mock_dataSift:
            mock_dataSift.return_value = devices['value']
            
            # Call the function with premade test data
            result = dataSift(devices, states, True)
            
            # Check for the same sized output and the correct first value 
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]['DeviceId'], '123')


if __name__ == '__main__':
    unittest.main()