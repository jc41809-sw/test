import matplotlib.pyplot as ml
import pandas as pd 
import re as regex
import datetime 
from matplotlib.backends.backend_pdf import PdfPages
import KB4_Data

#formatting that into a string
now = datetime.datetime.now()
#formatting that into a string
now = now.strftime("%Y%m%d")
groups = ['Executive Report']
groups += KB4_Data.group_metrics()


enrollments = KB4_Data.allenr()


def df_to_pdf(ChartDataComb, name, ChartDataU, ChartDataSW):
        """Used to create the data models using matplotlib piecharts"""

        colors = ['green', 'red']
        labels = ['Completed', 'Not Completed']
   
   

        fig, axes = ml.subplot_mosaic([['upper left', 'upper right'],
                                      ['bottom','bottom']],
                              figsize=(11.7, 8.3), layout="constrained")
      

        #Creating and pasting the first pie chart
        if ChartDataU[0] + ChartDataU[1] >=1:
            axes['upper left'].pie(ChartDataU, labels=labels, colors=colors,autopct='%1.1f%%',startangle=90,textprops={'color': 'white'})
            axes['upper left'].set_title(f' User %')
            axes['upper left'].legend(labels)
            axes['upper left'].text(-0.5, -1.1, f"Completed: {int(ChartDataU[0])} Not Completed: {int(ChartDataU[1])}", va='center')
        else:
            axes['upper left'].remove()    

        if ChartDataSW[0] + ChartDataSW[1] >=1:
            axes['upper right'].pie(ChartDataSW, labels=labels, colors=colors,autopct='%1.1f%%',startangle=90,textprops={'color': 'white'})
            axes['upper right'].set_title(f' Student Worer %')
            axes['upper right'].legend(labels)
            axes['upper right'].text(-0.5, -1.1, f"Completed: {int(ChartDataSW[0])} Not Completed: {int(ChartDataSW[1])}", va='center')
        else:
            axes['upper right'].remove() 

        if ChartDataComb[0] + ChartDataComb[1] >=1:
            axes['bottom'].pie(ChartDataComb, labels=labels, colors=colors,autopct='%1.1f%%',startangle=90,textprops={'color': 'white'})
            axes['bottom'].set_title(f' Combined %')
            axes['bottom'].legend(labels)
            axes['bottom'].text(-0.5, -1.1, f"Completed: {int(ChartDataComb[0])} Not Completed: {int(ChartDataComb[1])}", va='center')
        else:
            axes['bottom'].remove() 
        
        fig.suptitle(f'{name} statistics')
        ml.close(fig)

        return fig


def filter_times(dataframe):
    """Uses the check year function to filter theough all the data and find the most recent trainings"""
    placer = 0
    #creating the return reference for the result
    return_frame = pd.DataFrame(columns=['Email', 'First Name', 'Last Name', 'Manager Email', 'Content','Status','Department', 'Division','College'])
    #looping through the dataframe for possible results
    for index in range(len(dataframe)):
            
            #if older than fall 2024 then dont add if that age or newer add
            newerFall = check_year(str(dataframe.loc[index, 'Content']))
            if newerFall == False:
                return_frame.loc[placer] = [dataframe.iloc[index,0],dataframe.iloc[index,1],dataframe.iloc[index,2],dataframe.iloc[index,3],dataframe.iloc[index,4],dataframe.iloc[index,5],dataframe.iloc[index,6],dataframe.iloc[index,7],dataframe.iloc[index,8]]
                placer+=1
           
    return return_frame


def check_year(checkStr):
    """A regular expression function for filtering out all older trainings
    TODO: Find a more automatic way to update the regular expression dates"""
    if 'Fall' not in checkStr and 'Spring' not in checkStr:
        return True
    if 'Fall' in checkStr:
        yearcheck = r'Fall.* 202[0-4].*'
        return bool(regex.search(yearcheck,checkStr))
    if 'Spring' in checkStr:
        yearcheck = r'Spring.* 202[0-4].*'
        return bool(regex.search(yearcheck,checkStr))
    else:
        
        return False
    

def filter_past_Due(frame):
    """A function to filter through all of the past due users"""
    #Creates a placer pointer for adding to the dataframe 
    placer = 0
    #creates the dataframe we will return
    return_frame =pd.DataFrame(columns=['Email', 'First Name', 'Last Name', 'Manager Email', 'Status','Department', 'Division','College'])
    #looping through the dataframe to compare the values 
    for index in range(len(frame)):
        #if pastdue add to the return dataframe
        if 'Passed' not in frame.loc[index,'Status']:
            new_row = frame.iloc[index]
            new_row = new_row.to_dict()
            return_frame.loc[placer] = [new_row['Email'],new_row['First Name'],new_row['Last Name'],new_row['Manager Email'],'Not Passed',new_row['Department'],new_row['Division'],new_row['College']]
            placer+=1
    #returning dataframe
    return return_frame


def Fac_Staff_nums(df):
    """Creates a tally of the passed and past due Faculty for the most recent campaign"""
    #Creates a list to contain the count for passed and pastdue
    pass_fail = [0,0]
    f = '-sw'
    #Lambda fuction used to count the passed and not passed in email
    focusUserData = df[df.apply(lambda x:f not in x.Email , axis=1)]
    pass_fail[0] = (focusUserData['Status'] == 'Passed').sum()
    pass_fail[1] = (focusUserData['Status'] != 'Passed').sum()
    return pass_fail


def Student_Worker_nums(df):
    """Creates a tally of the passed and past due Student  Workers for the most recent campaign"""
    #Creates a list to contain the count for passed and pastdue
    pass_fail = [0,0]
    s = '-sw'
    #Lambda fuction used to count the passed and not passed in email
    focusStudentData = df[df.apply(lambda x:s in x.Email , axis=1)]
    pass_fail[0] = (focusStudentData['Status'] == 'Passed').sum()
    pass_fail[1] = (focusStudentData['Status'] != 'Passed').sum()
    return pass_fail


def combine_numbers(sw,users):
    """Creates a tally of the number of passed vs not passed for all divisions"""
    comb = [0,0]
    comb[0] += sw[0]+users[0]
    comb[1] += sw[1]+users[1]

    return comb


def Excel_table(data, name):
    """ Used to create an excel book that contains a table for each one of the divisions"""
   
    #Instantiates an excel file with the name of the division and the date
    with pd.ExcelWriter(f'C:\\Know_Be_4_Reports\\{name} {now}.xlsx', engine='xlsxwriter') as writer:
        data.to_excel(writer, sheet_name='Sheet1', startrow=1, header=False, index=False)
        worksheet = writer.sheets['Sheet1']
        (max_row, max_col) = data.shape
        column_settings = []
        # Create a list of column headers, to use in add_table().
        column_settings = [{"header": column} for column in data.columns]
        # Add the table.
        worksheet.add_table(0, 0, max_row, max_col - 1, {'columns': column_settings})
        # Make the columns wider for clarity.
        worksheet.set_column(0, max_col - 1, 12)


if __name__ == "__main__":
  #instantiates an executive report file to write to 
  with PdfPages('C:\\Know_Be_4_Reports\\Executive Report.pdf') as f:
    
    #looping through all of the sheets
    for index in range(len(groups)):
        print('hi')
        #creating and processing a dataframe for each name
        if groups[index] != 'Executive Report':
            KPI_frame = KB4_Data.df_create(enrollments, groups[index])
        else:
             KPI_frame = KB4_Data.df_create_exec(enrollments)
        #Passing that dataframe through a filter for the more recent trainings
        KPI_frame = filter_times(KPI_frame)
        #taking the dataframe and passing it into a method to get the information for users and student workers
        user_numbers = Fac_Staff_nums(KPI_frame)
        SW_numbers = Student_Worker_nums(KPI_frame)
        comb_numbers = combine_numbers(SW_numbers, user_numbers)
        #creates an updated dataframe based on the past due users
        KPI_frame = filter_past_Due(KPI_frame)
        #Turning the dataframes into a table
        if comb_numbers[1] > 1:
            Excel_table(KPI_frame, groups[index])
        figure = df_to_pdf(comb_numbers,groups[index],user_numbers,SW_numbers)
        f.savefig(figure)
        



