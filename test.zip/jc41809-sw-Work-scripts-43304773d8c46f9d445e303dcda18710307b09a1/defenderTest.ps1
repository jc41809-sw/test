# Import required modules
Import-Module Az.Accounts

# Define output file
$outfile = "Defenderdata.json"

# Acquire a token using DefaultAzureCredential
$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com/.default").Token

# Define headers for the API request
$headers = @{
    "Content-Type"  = "application/json"
    "Accept"        = "application/json"
    "Authorization" = "Bearer $token"
}

# Define API endpoint and parameters
$apiUrl = "https://graph.microsoft.com/v1.0/security/alerts_v2"
# $top = 10000
# $skip = 0
# $scopes = "SecurityAlert.Read.All"

# Make the API request
$response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method Get

# Save the response to a JSON file
$response | ConvertTo-Json -Depth 10 | Out-File -FilePath $outfile -Encoding utf8