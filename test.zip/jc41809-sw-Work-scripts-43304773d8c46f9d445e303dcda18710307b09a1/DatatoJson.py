import pandas as pd 
import re as regex
import datetime 
import KB4_Data
import json

#formatting that into a string
now = datetime.datetime.now()
#formatting that into a string
now = now.strftime("%Y%m%d")
#calls the enrollmennts and groups from the referencing code 
groups = KB4_Data.group_metrics()
enrollments = KB4_Data.allenr()

def filter_times(dataframe):
    """ This method willl call another method to check to see if the training is recent using regex
    """

    placer = 0
    #creating the return reference for the result
    return_frame = pd.DataFrame(columns=['Email', 'First Name', 'Last Name', 'Manager Email', 'Content','Status','Department', 'Division','College'])
    #looping through the dataframe for possible results
    for index in range(len(dataframe)):
            #if older than fall 2024 then dont add if that age or newer add
            newerFall = check_year(str(dataframe.loc[index, 'Content']))
            if newerFall == False:
                if dataframe.iloc[index, 3] != None:
                   dataframe.iloc[index, 3] = str(dataframe.iloc[index, 3])
                   dataframe.iloc[index, 3] = dataframe.iloc[index, 3].replace('@georgiasouthern.edu', '')
                return_frame.loc[placer] = [dataframe.iloc[index,0],dataframe.iloc[index,1],dataframe.iloc[index,2],dataframe.iloc[index,3],dataframe.iloc[index,4],dataframe.iloc[index,5],dataframe.iloc[index,6],dataframe.iloc[index,7],dataframe.iloc[index,8]]
                placer+=1
    #returns the resulting frame        
    return return_frame



def check_year(checkStr):
    """Using regular expression this will assess whether the training is recent or not 
    TO DO: find a smarter way to automate the year check comparitavely"""
    #checks to see if the date of the training is older than fall 23 True if yes False if not has to be updated or automated
    if 'Fall' in checkStr:
        yearcheck = r'.*[2-9][0-9][0-9][0-3].*'
        return bool(regex.search(yearcheck,checkStr))
      #checks to see if the date of the training is older than Spring 24 True if yes False if not has to be updated or automated
    if 'Spring' in checkStr:
        yearcheck = r'.*[2-9][0-9][0-9][0-4].*'
        return bool(regex.search(yearcheck,checkStr))
    else:
        #if it is neither then return false  
        return False
    

def filter_past_Due(frame):
    """Filters out all of the passed users in the dataframe"""
    
    #Creates a placer pointer for adding to the dataframe 
    placer = 0
    #creates the dataframe we will return
    return_frame =pd.DataFrame(columns=['Email', 'First Name', 'Last Name', 'Manager Email', 'Status','Department', 'Division','College'])
    #looping through the dataframe to compare the values 
    for index in range(len(frame)):
        #if pastdue add to the return dataframe
        if 'Past Due' in frame.loc[index,'Status']:
            new_row = frame.iloc[index]
            new_row = new_row.to_dict()
            new_row['Email'] = new_row['Email'].replace('@georgiasouthern.edu', '')
            new_row['Content'] = new_row['Content'].replace('- FAC/STAFF', '')
            new_row['Content'] = new_row['Content'].replace('- Student Workers', '')
            return_frame.loc[placer] = [new_row['Email'],new_row['First Name'],new_row['Last Name'],new_row['Manager Email'],new_row['Status'],new_row['Department'],new_row['Division'],new_row['College']]
            placer+=1
    #returning dataframe
    return return_frame

if __name__ == "__main__":
    
    #looping through all of the sheets
    for index in range(len(groups)):
        #creating and processing a dataframe for each name
        KPI_frame = KB4_Data.df_create(enrollments, groups[index])   
        #Passing that dataframe through a filter for the more recent trainings
        KPI_frame = filter_times(KPI_frame) 
        #creates an updated dataframe based on the past due users
        KPI_frame = filter_past_Due(KPI_frame)
        #Turning the dataframes into a json object and outputting 
        dftoJson = KPI_frame.to_json(f'{groups[index]}.json', orient='records')
      

        
     
        


