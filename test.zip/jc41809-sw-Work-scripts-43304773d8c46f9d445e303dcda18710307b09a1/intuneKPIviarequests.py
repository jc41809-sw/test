#!/usr/bin/env python3
# Jaheim Cain
# Aggregates the data into a json file showing all non-encrypted devices in Intune

from azure.identity import DefaultAzureCredential
import requests
import json


outfile = 'intuneKPI.json'

output = list()

# Acquire a credential object
token_credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)

header = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': f'Bearer {token_credential.get_token("https://api.manage.microsoft.com/.default").token}',

}

def dataSift(devices , states, test):
    if test == True:
        global outfile
        outfile = 'intuneKPI_test.json'
    
    count =0
    managementkey = 0

    for mindex in states['value']:
        if 'Managed' in mindex['managementStateName']:
            managementkey = mindex['managementStateKey']
            

    for index in devices['value']:
        
        if  index['managementStateKey'] == managementkey:
            
            if  index['encryptionState'] == 0:
                    count+=1
                    index['encryptionState'] == 'False'
                    index['managementStateKey'] = 'Managed'

                    non_encrypted_device = {'managementState' : index['managementStateKey'],'DeviceId' : index['deviceId'],'DeviceName' : index['deviceName'],
                    'enrolledDateTime' : index['enrolledDateTime'],'lastSyncDateTime' : index['lastSyncDateTime'],'azureADDeviceId' : index['azureADDeviceId'],'azureADRegistered' : index['azureADRegistered'],
                    'osVersion' : index['osVersion'],'easDeviceId' : index['easDeviceId'],'serialNumber' : index['serialNumber'],'userId' : index['userId'],'rowLastModifiedDateTimeUTC' : index['rowLastModifiedDateTimeUTC'],
                    'manufacturer' : index['manufacturer'],'model' : index['model'],'operatingSystem' : index['operatingSystem'],'isDeleted' : index['isDeleted'],
                    'encryptionState' : False if index['encryptionState'] == 0 else True  ,
                    'ethernetMacAddress' : index['ethernetMacAddress'],'primaryUser' : index['primaryUser'],
                    }
                    output.append(non_encrypted_device)
    
    print (count)
    return (output)


def checklength(devices):
     device_count = 0
     for index in devices['value']:
          device_count += 1
     return device_count

if __name__ == "__main__":
    top = 10000
    skip = 0
    

    result_for_devices = requests.get(f'https://fef.msua04.manage.microsoft.com/ReportingService/DataWarehouseFEService/managementStates?api-version=v1.0',  headers=header )
    data_states = result_for_devices.json()

    while  True:        
       
        result_for_devices = requests.get(f'https://fef.msua04.manage.microsoft.com/ReportingService/DataWarehouseFEService/devices?api-version=v1.0&$skip={skip}&$top={top}',  headers=header )
        data_devices = result_for_devices.json()
        length_of_response = checklength(data_devices)
        if length_of_response > 1:
            dataSift(data_devices, data_states, False)
            skip+=top
        else:
              break

  
    print(len(output))
    with open (f'{outfile}', 'w') as f:
         json.dump(output, f, indent=4)