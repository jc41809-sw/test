
$Search_folder_path = "C:\Users\jc41809-sw\Downloads\AD_Csvs"

$deptList = @('AAAS','ADMS','ITSA','CLCS','COMP','CTOF','ENTS','EXEC','FADS','HLTH','HMRC','ISEC','LGAF','NWTC','REGS','UADV','ARMA','BASS','SMAD','SSVC','STSC','STSR','CLAD','ENRL','ISYS','FINC','ITEC','ITLT','ITSS','ITSM','PUSF','VPAA','VPIT','VPBF','VPEM','PRES','VPSA','VPOR')

$count = 0
$deptLen = $deptList.Length

for ($i = 0; $i -le $deptLen; $i++){
    $deptname = $deptList[$i]
    Write-Host "OU=$deptname,OU=FacultyStaff,OU=gasou,DC=ad,DC=georgiasouthern,DC=edu"
    $count += (Get-ADUser -SearchBase "OU=$deptName,OU=FacultyStaff,OU=gasou,DC=ad,DC=georgiasouthern,DC=edu" -Filter *).Count
    $AD_dept = Get-ADUser -SearchBase "OU=$deptName,OU=FacultyStaff,OU=gasou,DC=ad,DC=georgiasouthern,DC=edu" -Filter * -Properties * |ConvertTo-Csv




if (Test-Path -path "$Search_folder_path\AD_$deptname.csv"){
    Set-Content -Path "$Search_folder_path\AD_$deptname.csv"-Value $AD_dept
}else{
     Add-Content -Path "$Search_folder_path\AD_$deptname.csv" -Value $AD_dept
}
}
Write-Host $count