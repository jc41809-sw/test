import pandas as pd
import datetime 

#formatting that into a string
now = datetime.datetime.now()
#formatting that into a string
now = now.strftime("%Y%m%d")



#Creating the dataframe based on the main and supporting data
enrollments = pd.read_csv('C:\\Know_Be_4_Records\\Kb4_AllEnrollmentsWithGroupInfo.csv')
users = pd.read_csv('C:\\Know_Be_4_Records\\Kb4_AllUsers.csv')
campaigns = pd.read_csv('C:\\Know_Be_4_Records\\Kb4_AllCampaigns.csv')


def df_create(data, group_name):
    """ This function is used to create a dataframe based off of the group that is passed through"""
    #Replaces all nan values with a more tangable value to detect
    data.fillna('Null', inplace=True)
    #creating the dataframe to return and search
    return_frame = pd.DataFrame(columns = [['Email','First Name', 'Last Name', 'Manager Email', 'Content','Status','Department', 'Division','College']])
    #an index for the return frame 
    placer = 0
    #looping through the dataframe and returning the rows with thee relavent group info
    for index in range(len(data)):
        if type(data.iloc[index,7]) == type(group_name):
            if group_name == data.iloc[index, 7]:
                return_frame.loc[placer] = [data.iloc[index,0],data.iloc[index,1],data.iloc[index,2],data.iloc[index,3],data.iloc[index,4],data.iloc[index,5],data.iloc[index,6],data.iloc[index,7],data.iloc[index,8]]
                placer+=1
    return return_frame    

def df_create_exec(data):
    """ This function is used to create a dataframe based off of the group that is passed through"""
    #Replaces all nan values with a more tangable value to detect
    data.fillna('Null', inplace=True)
    #creating the dataframe to return and search
    return_frame = pd.DataFrame(columns = [['Email','First Name', 'Last Name', 'Manager Email', 'Content','Status','Department', 'Division','College']])
    #an index for the return frame 
    placer = 0
    #looping through the dataframe and returning the rows with thee relavent group info
    for index in range(len(data)):
                return_frame.loc[placer] = [data.iloc[index,0],data.iloc[index,1],data.iloc[index,2],data.iloc[index,3],data.iloc[index,4],data.iloc[index,5],data.iloc[index,6],data.iloc[index,7],data.iloc[index,8]]
                placer+=1
    return return_frame    

def group_metrics():
    """This method gets a list of all of the different groups reported to the KB4 data"""
    
    #Dropping all of the duplicate cells based on the user groups data
    groupMetric = users['custom_field_1']
    groupMetric = groupMetric.drop_duplicates()
    #converting the result from a series to a frame to better work with
    groupMetric.fillna('Null', inplace=True)
    groupMetric = groupMetric.to_list()
    

    return groupMetric
    
def allenr():
       """ Uses the KB4 all enrollments with group info, and the all users return information to create a daatframe with all relavent information for aggregation """

       #Creating a dataframe that will represent all of the outliers
       outliers = []
        #Creates a return dataframe for export
       return_frame = pd.DataFrame(columns = [['Email','First Name', 'Last Name', 'Manager Email', 'Content','Status','Department', 'Division','College']])
        #Creates a narrowed reference dataframe from the main users dataframe 
       groups = users[['id','manager_email','department','custom_field_1','custom_field_3','Group_Names', ]]
        #Creates a narrowed reference dataframe from the main enrollments dataframe 
       user_enrollments = enrollments[['id', 'email','first_name', 'last_name','campaign_name', 'status', ]]
       #A pointer for the return dataframe 
       returnplacer = 0
       #a pointer to make sure that the group reference does not go out of bounds
       group_row = 0
       #an index for the loop
       cindex = 0
       #Creating the dataframe that will be returned for searching
       for group_row in range(len(users)):
        try:
           #In the case that the ids are different the we will try to check the larger dataframe for the user id
           if users.loc[group_row,'id'] != user_enrollments.loc[cindex, 'id']:
             try:
                 swindex = user_enrollments['id'].eq(users.loc[group_row,'id']).idxmax()
                 cindex = swindex
            # If there is an error or the id doesn't exits then we add the line's information to the outliers list
             except:
                  outlie = {'id':int(groups.iloc[group_row,0]),
                      'ManagerEmail':groups.iloc[group_row,1],
                      'Department':groups.iloc[group_row,2],
                      'Division':groups.iloc[group_row,3],
                      'College':groups.iloc[group_row,4],
                      'Group':groups.iloc[group_row,5]}
                  outliers.append(outlie)
            #adding to thee return frame as long as the ids match
           while cindex < len(user_enrollments) and user_enrollments.iloc[cindex, 0] == users.loc[group_row,'id']:
               return_frame.loc[returnplacer] = user_enrollments.iloc[cindex, 1],user_enrollments.iloc[cindex,2], user_enrollments.iloc[cindex, 3],groups.iloc[group_row, 1],user_enrollments.iloc[cindex, 4],user_enrollments.iloc[cindex, 5], groups.iloc[group_row, 2],groups.iloc[group_row, 3],groups.iloc[group_row, 4]
               returnplacer+= 1
               cindex+=1
        # If the pointer gopes out of bounds of all users then we add the the offending's line's information to the outliers list
        except:
            outlie = {'id':int(groups.iloc[group_row,0]),
                      'ManagerEmail':groups.iloc[group_row,1],
                      'Department':groups.iloc[group_row,2],
                      'Division':groups.iloc[group_row,3],
                      'College':groups.iloc[group_row,4],
                      'Group':groups.iloc[group_row,5]}
            outliers.append(outlie)
       return return_frame


def allusers():
   """Returns all user data"""
   return users 


def alltrainings():
   """returns all training data"""
   return campaigns


