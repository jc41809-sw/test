import requests

url = 'https://us.api.knowbe4.com/v1/training/campaigns'

response = requests.get(url)

if response.status_code == 200:
        print("Request successful")
else:
        print(f"Request failed with status code {response.status_code}")

if response.status_code == 200:
        data = response.json() # If the response is in JSON format
        # Do something with the data
        print(data)