from azure.identity import DefaultAzureCredential
import requests
import json
import pandas

outfile = 'Defenderdata.json'

output = list()

# Acquire a credential object
token_credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)

header = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': f'Bearer {token_credential.get_token("https://graph.microsoft.com/.default").token}',

}

if __name__ == "__main__":
    top = 10000
    skip = 0
    scopes = 'SecurityAlert.Read.All'

    result_for_alerts = requests.get(f'	https://graph.microsoft.com/v1.0/security/alerts_v2',  headers=header )
    data_states = result_for_alerts.json()

    with open (f'{outfile}', 'w') as f:
         json.dump(data_states, f, indent=4)
