import unittest
from KB4ExcelAndPDF import filter_past_Due, Fac_Staff_nums, Student_Worker_nums, combine_numbers
import pandas as pd 
import KB4Data as kb4data

references = kb4data.df_create_exec(kb4data.enrollments)

class TestMethods(unittest.TestCase):
    
    def test_filter_past_Due(self):
        self.assertNotEqual (type(filter_past_Due(references)), type(-1))

    def test_Fac_Staff_nums(self):
        self.assertNotEqual (Fac_Staff_nums(references), [-1,-1])

    def test_Strudent_worekers_nums(self):
        self.assertNotEqual ( Student_Worker_nums(references), [-1,-1])

    def test_combined_nums(self):
        self.assertNotEqual (combine_numbers(references), [-1,-1])


if __name__ == "__main__":
    unittest.main()