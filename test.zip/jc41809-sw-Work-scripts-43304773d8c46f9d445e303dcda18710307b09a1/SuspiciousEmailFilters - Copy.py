import json
import os



placeholderBoolean = []



def jsonReader():
   
   try:
      #opens the emails.txt file in read
      with open ('emails.txt', 'r') as f:
       
       #loops through the file 
       for place in f:
          
          # a variable that contians the  singular emails
          emails = place.split()

          #calls a placeholder check method using placeholder email
          emailToJson(emails)

          #if there is an error with the email file print placehoder
   except Exception as e :
      print("OOF At 1")





def emailToJson(emails):
   try:
    
#     holderJson = {
#     "TRASH": "direct",
#     "rollno": 56,
#     "cgpa": 8.6,
#     "phonenumber": "9976770500"
# }
    
#     holderJsonObject = json.dumps(holderJson, indent = 4)

#     with open("sample.json", "w") as outfile:
#         outfile.write(holderJsonObject)

#placeholder for str but takes the json and puts it into a string 
    with open("sample.json", "r") as outfile:
        teststr = json.load(outfile)

  
# placeholer error to check if email does not exist
   except Exception as e:
      print ("Error Email does not exist")


   placeholderCheck(teststr, emails)
   



def placeholderCheck(teststr, email):
   try:

    for line in teststr:
               #place conditions for regex regarding json file 
               if "TRASH" in line or "TRASH" in line or "TRASH" in line:
                        is_suspicious = True
                      #prints out that the email has suspicious filters
                        print (email + "has suspicious filters: " + is_suspicious + " Keeping results")

                        
               else:
                   #line to remove the not needed json files
                   os.remove("sample.json")

    


       #adds to an srray that keeps track of successfully read email filters   
    placeholderBoolean.append(True)
      
        

   except Exception as e:
      print ("json could not be read saving to log")

# exceotion for if Json file cannot be decoded
   except json.JSONDecodeError:  
            #prints that the emails filter could not be decoded
            print(f"Warning: Could not decode JSON for {email}. Check the GAM output.")
            is_suspicious = True # Treat as suspicious if JSON parsing fails

# here goes any extra exceptions for this process
   # except subprocess.CalledProcessError as e:
    #    print(f"Error running GAM for {email}: {e}")
    #    print(f"GAM Output: {e.stderr}") # Print error output from GAM




jsonReader()

success = 0
failure = 0

for i in len(placeholderBoolean):
    if True:
        success += 1
    else: 
        failure += 1