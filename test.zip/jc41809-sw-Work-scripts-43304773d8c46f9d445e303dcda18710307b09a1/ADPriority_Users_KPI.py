import pandas as pd
import datetime
from datetime import timedelta
import json



#Input file path
filepath_in = 'AD_PUser_properties.csv'



#output file path and  name for the output
filepath_out = 'AD_users_Priority.json'
KPIname = 'AD_PUPD'

#Gettig current date 
now = datetime.datetime.now()
formatted_date = now.strftime("%m/%d/%Y")

#dataframe used for processing all of the information
pastdue_passwords = pd.read_csv(filepath_in)



   


def process_by_dates():
    #used to keep track of the return dataframe 
    placer=0
    #the frame that will be used to convert to json
    return_frame = pd.DataFrame(columns=['SamAccountName','PasswordLastSet'])
    #replacing all null values with a date of 1700 jan 1st
    pastdue_passwords.fillna('1700-01-01 00:00:00', inplace=True)
    #loops through the dataframe to get password info
    for index in range(len(pastdue_passwords)):
            #converts the passwords into a datetime object
            date = (pastdue_passwords.loc[index]['PasswordLastSet'])
            date = pd.to_datetime(date)
            #if datetime is a year or more old it goes on the list 
            if date < now - timedelta(days=90):
                return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'], pastdue_passwords.loc[index]['PasswordLastSet']] 
                placer+=1
    return return_frame

def process_by_ldates():
    #used to keep track of the return dataframe 
    placer=0
    #the frame that will be used to convert to json
    return_frame = pd.DataFrame(columns=['SamAccountName','LastLogonDate'])
    #replacing all null values with a date of 1700 jan 1st
    pastdue_passwords.fillna('1700-01-01 00:00:00', inplace=True)
    #loops through the dataframe to get password info
    for index in range(len(pastdue_passwords)):
            #converts the passwords into a datetime object
            date = (pastdue_passwords.loc[index]['LastLogonDate'])
            date = pd.to_datetime(date)
            #if datetime is a year or more old it goes on the list 
            if date < now - timedelta(days=90):
                return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'], pastdue_passwords.loc[index]['LastLogonDate']] 
                placer+=1
    return return_frame

def disabled_accts():
     #used to keep track of the return dataframe 
    placer=0
    #the frame that will be used to convert to json
    return_frame = pd.DataFrame(columns=['SamAccountName','Enabled'])
#Loops through the data and adds to retrun frame if accounts are disabled 
    for index in range(len(pastdue_passwords)):
          if pastdue_passwords.loc[index]['Enabled'] == False:
               return_frame.loc[placer] = [pastdue_passwords.loc[index]['SamAccountName'], pastdue_passwords.loc[index]['Enabled']] 
               placer+=1
    return return_frame
               


if __name__ == '__main__':
#Creating dataframes for the objects 
   renewed_pwd_needed = process_by_dates()
   logon_needed = process_by_ldates()
   disabled_acct = disabled_accts()



#Converting the dataframe into and excel book
   with pd.ExcelWriter(f'{KPIname}.xlsx', engine='xlsxwriter') as writer:
       renewed_pwd_needed.to_excel(writer, sheet_name='AD Metrics1', index=False, header=True)
       logon_needed.to_excel(writer, sheet_name='AD Metrics2', index=False, header=True)
       disabled_acct.to_excel(writer, sheet_name='AD Metrics3', index=False, header=True)
       

